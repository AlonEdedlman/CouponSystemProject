package coupon.system;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.core.MediaType;

import core.couponSys.ClientType;
import core.couponSys.CouponSystem;
import core.exceptions.CouponSystemException;
import core.facade.AdminFacade;
import core.facade.CompanyFacade;
import core.facade.CustomerFacade;
import core.facade.client.Client;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
		String name = request.getParameter("name");
		String password = request.getParameter("password");
		String clientType = request.getParameter("clientType");
		Client facade;
		try {
			facade = CouponSystem.getInstance().logIn(name, password,ClientType.valueOf(clientType));
			
			
			
		} catch (CouponSystemException e) {
			facade = null;
			System.out.println(e.getMessage());
		}

		
		request.getSession().setAttribute("facade", facade);
       
		
		if(facade !=null){
			
			Cookie userNameCookie = new Cookie("name", name);
			Cookie passwordCookie = new Cookie("password", password);
			Cookie clientTypeCookie = new Cookie("clientType", clientType);
			userNameCookie.setMaxAge(60*60*24);
			passwordCookie.setMaxAge(60*60*24);
			clientTypeCookie.setMaxAge(60*60*24);
			response.addCookie(userNameCookie);
			response.addCookie(passwordCookie);
			response.addCookie(clientTypeCookie);
			
			if(facade instanceof CustomerFacade){
				response.sendRedirect("cust/custPage3.html");
				
				
			}else if(facade instanceof CompanyFacade){
				response.sendRedirect("comp/compPage3.html");
			}else{
				response.sendRedirect("admin/adminPage3.html");
			}
		}else{
			response.sendRedirect("login/login.html");
		}
	}
}
