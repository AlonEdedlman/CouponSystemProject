package coupon.system;

import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import core.beans.Coupon;
import core.beans.CouponType;
import core.exceptions.CouponSystemException;
import core.facade.CompanyFacade;
import core.facade.CustomerFacade;
import core.facade.client.Client;

@Path("customer")
public class CustomerServ {

	@Context
	HttpServletRequest request;
	@Context
	private HttpServletResponse response;
	
	private CustomerFacade facade = null;

	public CustomerServ() throws CouponSystemException {

	}
	
	private void getUpdatedFacade() {
		Client client = (Client) request.getSession().getAttribute("facade");
		if (client instanceof CustomerFacade) {
			facade = (CustomerFacade) client;
		} else {
			facade = null;
		}
	}

	@GET
	@Path("coupon")
	public Response getAllPurchasedCoupons() {
		getUpdatedFacade();
		if (facade != null) {
			Collection<Coupon> coreResult;
			try {
				coreResult = facade.getAllPurchasedCoupons();
				Collection<CouponWeb> result = CouponWeb.convertToWebCoupons(coreResult);
				GenericEntity<Collection<CouponWeb>> genericEntity = new GenericEntity<Collection<CouponWeb>>(result) {
				};
				return Response.ok(genericEntity).status(200).build();
			} catch (CouponSystemException e) {
				e.printStackTrace();
				return Response.ok(e.getMessage()).status(500).build();
			}
		}
		return Response.ok("noFacade").status(200).build();

	}

	@GET
	@Path("purchase")
	public Response getAllCouponsToPurchase() {
		getUpdatedFacade();
		if (facade != null) {
			Collection<Coupon> coreResult;
			try {
				coreResult = facade.getAllCouponsToPurchase();
				Collection<CouponWeb> result = CouponWeb.convertToWebCoupons(coreResult);
				GenericEntity<Collection<CouponWeb>> genericEntity = new GenericEntity<Collection<CouponWeb>>(result) {
				};
				return Response.ok(genericEntity).status(200).build();
			} catch (CouponSystemException e) {
				e.printStackTrace();
				return Response.ok(e.getMessage()).status(500).build();
			}
		}
		return Response.ok("noFacade").status(200).build();

	}

	@GET
	@Path("getByType/{type}")
	public Response getAllPurchasedCouponsByType(@PathParam("type") String type) {
		getUpdatedFacade();
		if (facade != null) {
			Collection<Coupon> coreResult;
			try {
				coreResult = facade.getPurchasedCouponsByType(CouponType.valueOf(type));
				Collection<CouponWeb> result = CouponWeb.convertToWebCoupons(coreResult);
				GenericEntity<Collection<CouponWeb>> genericEntity = new GenericEntity<Collection<CouponWeb>>(result) {
				};
				return Response.ok(genericEntity).status(200).build();
			} catch (CouponSystemException e) {
				e.printStackTrace();
				return Response.ok(e.getMessage()).status(500).build();
			}
		}

		return Response.ok("noFacade").status(200).build();

	}

	@GET
	@Path("getByLimit/{limit}")
	public Response getAllPurchasedCouponByLimit(@PathParam("limit") double limit) {
		getUpdatedFacade();
		if (facade != null) {
			Collection<Coupon> coreResult;
			try {
				coreResult = facade.getPurchasedCouponsByPrice(limit);
				Collection<CouponWeb> result = CouponWeb.convertToWebCoupons(coreResult);
				GenericEntity<Collection<CouponWeb>> genericEntity = new GenericEntity<Collection<CouponWeb>>(result) {
				};
				return Response.ok(genericEntity).status(200).build();
			} catch (CouponSystemException e) {
				e.printStackTrace();
				return Response.ok(e.getMessage()).status(500).build();
			}
		}
		return Response.ok("noFacade").status(200).build();

	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("coupon")
	public Response purchaseCoupon(CouponWeb couponWeb) {

		getUpdatedFacade();
		if(facade != null){
			Coupon coupon = couponWeb.convertToCoupon();
			try {
				facade.purchaseCoupon(coupon);
				return Response.ok(couponWeb).status(200).build(); 
			} catch (CouponSystemException e) {
				e.printStackTrace();
				return Response.ok(e.getMessage()).status(500).build();
			}
		}
		return Response.ok("noFacade").status(200).build();
	}

}
