package coupon.system;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

import core.beans.Company;
import core.beans.Coupon;
import core.beans.CouponType;

@XmlRootElement
public class CouponWeb implements Serializable{
	private long id;
	private String title;
	private long startDate;
	private long endDate;
	private int amount;
	private String type;
	private String message;
	private double price;
	private String image;


public CouponWeb(){
	

	
}

public CouponWeb(Coupon coupon) {
	
	super();
	this.id = coupon.getId();
	this.title = coupon.getTitle();
	this.startDate = coupon.getStartDate().getTime();
	this.endDate = coupon.getEndDate().getTime();
	this.amount = coupon.getAmount();
	this.type = coupon.getType().toString();
	this.message = coupon.getMessage();
	this.price = coupon.getPrice();
	this.image = coupon.getImage();
}


public Coupon convertToCoupon() {
	Coupon result = new Coupon(this.id, this.title, new Date(this.startDate) , new Date(this.endDate), this.amount, CouponType.valueOf(this.type), this.message, this.price, this.image);
	return result;
}

public static Collection<Coupon> convertToCoupon(Collection<CouponWeb> coupons) {
	Collection <Coupon> result = new ArrayList<>();
	for (CouponWeb c : coupons) {
		result.add(c.convertToCoupon());
	}
	return result;
}

public static Collection<CouponWeb> convertToWebCoupons(Collection<Coupon> coupons) {
	Collection<CouponWeb> result = new ArrayList<>();
	for (Coupon c : coupons) {
		result.add(new CouponWeb(c));
	}
	return result;
}

public long getId() {
	return id;
}

public void setId(long id) {
	this.id = id;
}

public String getTitle() {
	return title;
}

public void setTitle(String title) {
	this.title = title;
}

public long getStartDate() {
	return startDate;
}

public void setStartDate(long startDate) {
	this.startDate = startDate;
}

public long getEndDate() {
	return endDate;
}

public void setEndDate(long endDate) {
	this.endDate = endDate;
}

public int getAmount() {
	return amount;
}

public void setAmount(int amount) {
	this.amount = amount;
}

public String getType() {
	return type;
}

public void setType(String type) {
	this.type = type;
}

public String getMessage() {
	return message;
}

public void setMessage(String message) {
	this.message = message;
}

public double getPrice() {
	return price;
}

public void setPrice(double price) {
	this.price = price;
}

public String getImage() {
	return image;
}

public void setImage(String image) {
	this.image = image;
}

@Override
public String toString() {
	return "CouponWeb [id=" + id + ", title=" + title + ", startDate=" + startDate + ", endDate=" + endDate
			+ ", amount=" + amount + ", type=" + type + ", message=" + message + ", price=" + price + ", image=" + image
			+ "]";
}


}
