package coupon.system;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;




public class CreateCoupon {
	

	@Context
	HttpServletRequest request;
	@Context
	private HttpServletResponse response;
	
	private CouponWeb coupon = null;

	public CreateCoupon() {

	}
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("getSessionCoupToCreate")
	private CouponWeb getCouponWebFromSession() {
		CouponWeb coupon = (CouponWeb) request.getSession().getAttribute("couponWeb");
		if (coupon instanceof CouponWeb) {
			return coupon;
		} 
		return null;
	}
	
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("directToImage/{coupon}")
	public String directToImage(@PathParam("coupon") CouponWeb couponWeb) throws IOException {

		request.getSession().setAttribute("couponToCreate", couponWeb);
		
		return "comp/compPage3.html#/img";
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("backToCreate/{image}")
	public String backToCreateCoup(@PathParam("image") String image) throws IOException {
		coupon = (CouponWeb) request.getSession().getAttribute("couponWeb");
		if (coupon instanceof CouponWeb) {
			coupon.setImage(image);
			request.getSession().setAttribute("couponToCreate", coupon);
		} 
		
		return "comp/compPage3.html#/create";
	}
	

	
}