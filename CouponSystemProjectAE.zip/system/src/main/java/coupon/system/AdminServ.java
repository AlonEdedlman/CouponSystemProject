package coupon.system;

import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import core.beans.Company;
import core.beans.Customer;
import core.couponSys.ClientType;
import core.couponSys.CouponSystem;
import core.exceptions.CouponSystemException;
import core.facade.AdminFacade;
import core.facade.CompanyFacade;
import core.facade.CustomerFacade;
import core.facade.client.Client;

@Path("admin")
public class AdminServ {

	@Context
	HttpServletRequest request;
	@Context
	private HttpServletResponse response;
	
	private AdminFacade facade = null;

	public AdminServ() {

	}
	
	private void getUpdatedFacade() {
		Client client = (Client) request.getSession().getAttribute("facade");
		if (client instanceof AdminFacade) {
			facade = (AdminFacade) client;
		} else {
			facade = null;
		}
	}

	@GET
	@Path("company")
	public Response getAllCompanies(){
		getUpdatedFacade();
		
		if (facade != null) {
			Collection<Company> coreResult;
			try {
				coreResult = facade.getAllCompanies();
				Collection<CompanyWeb> result = CompanyWeb.convertToWebCompanies(coreResult);
				GenericEntity<Collection<CompanyWeb>> genericEntity = new GenericEntity<Collection<CompanyWeb>>(result) {
				};
				return Response.ok(genericEntity).status(200).build();
			} catch (CouponSystemException e) {
				e.printStackTrace();
				return Response.ok(e.getMessage()).status(500).build();
			}
			
		}
		return Response.ok("noFacade").status(200).build();

	}

	@GET
	@Path("company/{id}")
	public Response getCompany(@PathParam("id") long compId) {
		getUpdatedFacade();
		if (facade != null) {
			Company coreResult;
			try {
				coreResult = facade.getCompany(compId);
				CompanyWeb result = new CompanyWeb(coreResult);
				return Response.ok(result).status(200).build();
			} catch (CouponSystemException e) {
				e.printStackTrace();
				return Response.ok(e.getMessage()).status(500).build();
			}
		}
		return Response.ok("noFacade").status(200).build();

	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("company")
	public Response createCompany(CompanyWeb companyWeb) {

		getUpdatedFacade();
		if(facade != null){
			Company company = companyWeb.convertToCompany();
			try {
				facade.createCompany(company);
				
				return Response.ok(companyWeb).status(200).build();
			} catch (CouponSystemException e) {
				e.printStackTrace();
				return Response.ok(e.getMessage()).status(500).build();
			}

		}
		return Response.ok("noFacade").status(200).build();
	}

	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("company")
	public Response updateCompany(CompanyWeb companyWeb) {
		getUpdatedFacade();
		if(facade != null){
			Company company = companyWeb.convertToCompany();
			try {
				facade.updateCompany(company);
				CompanyWeb result = new CompanyWeb(facade.getCompany(companyWeb.getId()));
				return Response.ok(result).status(200).build();
			} catch (CouponSystemException e) {
				e.printStackTrace();
				return Response.ok(e.getMessage()).status(500).build();
			}
		}
		return Response.ok("noFacade").status(200).build();
	}

	@DELETE
	@Path("company/{id}")
	public Response deleteCompany(@PathParam("id") long compId) {
		getUpdatedFacade();
		if(facade != null){
			try {
				Company company = facade.getCompany(compId);
				facade.deleteCompany(company);
				CompanyWeb result = new CompanyWeb(company);
				return Response.ok(result).status(200).build();
			} catch (CouponSystemException e) {
				e.printStackTrace();
				return Response.ok(e.getMessage()).status(500).build();
			}
		}
		return Response.ok("noFacade").status(200).build();

	}

	@GET
	@Path("customer")
	public Response getAllCustomers() {
		getUpdatedFacade();
		if (facade != null) {
			Collection<Customer> coreResult;
			try {
				coreResult = facade.getAllCustomers();
				Collection<CustomerWeb> result = CustomerWeb.convertToWebCustomers(coreResult);
				GenericEntity<Collection<CustomerWeb>> genericEntity = new GenericEntity<Collection<CustomerWeb>>(result) {
				};
				return Response.ok(genericEntity).status(200).build();
			} catch (CouponSystemException e) {
				e.printStackTrace();
				return Response.ok(e.getMessage()).status(500).build();
			}
		}
		return Response.ok("noFacade").status(200).build();

	}

	@GET
	@Path("customer/{id}")
	public Response getCustomer(@PathParam("id") long custId) {
		getUpdatedFacade();
		if (facade != null) {
			Customer coreResult;
			try {
				coreResult = facade.getCustomer(custId);
				CustomerWeb result = new CustomerWeb(coreResult);
				return Response.ok(result).status(200).build();
			} catch (CouponSystemException e) {
				e.printStackTrace();
				return Response.ok(e.getMessage()).status(500).build();
			}
		}
		return Response.ok("noFacade").status(200).build();

	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("customer")
	public Response createCustomer(CustomerWeb customerWeb) {

		getUpdatedFacade();
		if(facade != null){
			Customer customer = customerWeb.convertToCustomer();
			try {
				facade.createCustomer(customer);
				return Response.ok(customerWeb).status(200).build();
			} catch (CouponSystemException e) {
				e.printStackTrace();
				return Response.ok(e.getMessage()).status(500).build();
			}
		}
		return Response.ok("noFacade").status(200).build();
	}

	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("customer")
	public Response updateCustomer(CustomerWeb customerWeb) {
		getUpdatedFacade();
		if(facade != null){
			Customer customer = customerWeb.convertToCustomer();
			try {
				facade.updateCustomer(customer);
				CustomerWeb result = new CustomerWeb(facade.getCustomer(customerWeb.getId()));
				return Response.ok(result).status(200).build();
			} catch (CouponSystemException e) {
				e.printStackTrace();
				return Response.ok(e.getMessage()).status(500).build();
			}
		}
		return Response.ok("noFacade").status(200).build();
	}

	@DELETE
	@Path("customer/{id}")
	public Response deleteCustomer(@PathParam("id") long custId) {
		getUpdatedFacade();
		if(facade != null){
			Customer customer;
			try {
				customer = facade.getCustomer(custId);
				facade.deleteCustomer(customer);
				CustomerWeb result = new CustomerWeb(customer);
				return Response.ok(result).status(200).build();
			} catch (CouponSystemException e) {
				e.printStackTrace();
				return Response.ok(e.getMessage()).status(500).build();
			}
		}
		return Response.ok("noFacade").status(200).build();

	}
}
