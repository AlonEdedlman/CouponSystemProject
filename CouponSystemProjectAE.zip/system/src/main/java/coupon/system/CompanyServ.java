package coupon.system;

import java.io.IOException;
import java.util.Collection;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;

import core.beans.Company;
import core.beans.Coupon;
import core.beans.CouponType;
import core.exceptions.CouponSystemException;
import core.facade.CompanyFacade;
import core.facade.client.Client;

@Path("company")
public class CompanyServ {
	

	@Context
	HttpServletRequest request;
	@Context
	private HttpServletResponse response;
	
	private CompanyFacade facade = null;

	public CompanyServ() {

	}

	private void getUpdatedFacade() {
		Client client = (Client) request.getSession().getAttribute("facade");
		if (client instanceof CompanyFacade) {
			facade = (CompanyFacade) client;
		} else {
			facade = null;
		}
	}

	@GET
	@Path("coupon")
	public Response getAllCoupons() {

		getUpdatedFacade();
		if (facade != null) {
			Collection<Coupon> coreResult;
			try {
				coreResult = facade.getAllCoupons();
				Collection<CouponWeb> result = CouponWeb.convertToWebCoupons(coreResult);
				GenericEntity<Collection<CouponWeb>> genericEntity = new GenericEntity<Collection<CouponWeb>>(result) {
				};
				return Response.ok(genericEntity).status(200).build();
			} catch (CouponSystemException e) {
				e.printStackTrace();
				return Response.ok(e.getMessage()).status(500).build();
			}

		}
		return Response.ok("noFacade").status(200).build();

	}

	@GET
	@Path("coupon/{id}")
	public Response getCoupon(@PathParam("id") long coupId) {
		getUpdatedFacade();
		if (facade != null) {

			Coupon coreResult;
			try {
				coreResult = facade.getCoupon(coupId);
				CouponWeb result = new CouponWeb(coreResult);
				return Response.ok(result).status(200).build();
			} catch (CouponSystemException e) {
				e.printStackTrace();
				return Response.ok(e.getMessage()).status(500).build();
			}
		}
		return Response.ok("noFacade").status(200).build();

	}

	@GET
	@Path("getByType/{type}")
	public Response getCouponByType(@PathParam("type") String type) {
		getUpdatedFacade();
		if (facade != null) {
			Collection<Coupon> coreResult;
			try {
				coreResult = facade.getCouponByType(CouponType.valueOf(type));
				Collection<CouponWeb> result = CouponWeb.convertToWebCoupons(coreResult);
				GenericEntity<Collection<CouponWeb>> genericEntity = new GenericEntity<Collection<CouponWeb>>(result) {
				};
				return Response.ok(genericEntity).status(200).build();
			} catch (CouponSystemException e) {
				e.printStackTrace();
				return Response.ok(e.getMessage()).status(500).build();
			}
		}
		return Response.ok("noFacade").status(200).build();

	}

	@GET
	@Path("getByLimit/{limit}")
	public Response getCouponByLimit(@PathParam("limit") double limit) {
		getUpdatedFacade();
		if (facade != null) {
			Collection<Coupon> coreResult;
			try {
				coreResult = facade.getCouponByLimit(limit);
				Collection<CouponWeb> result = CouponWeb.convertToWebCoupons(coreResult);
				GenericEntity<Collection<CouponWeb>> genericEntity = new GenericEntity<Collection<CouponWeb>>(result) {
				};
				return Response.ok(genericEntity).status(200).build();
			} catch (CouponSystemException e) {
				e.printStackTrace();
				return Response.ok(e.getMessage()).status(500).build();
			}
		}
		return Response.ok("noFacade").status(200).build();

	}

	@GET
	@Path("getUntilEndDate/{endDate}")
	public Response getCouponUntilEndDate(@PathParam("endDate") long endDate) {
		getUpdatedFacade();
		if (facade != null) {
			Collection<Coupon> coreResult;
			try {
				coreResult = facade.getCouponUntilEndDate(new Date(endDate));
				Collection<CouponWeb> result = CouponWeb.convertToWebCoupons(coreResult);
				GenericEntity<Collection<CouponWeb>> genericEntity = new GenericEntity<Collection<CouponWeb>>(result) {
				};
				return Response.ok(genericEntity).status(200).build();
			} catch (CouponSystemException e) {
				e.printStackTrace();
				return Response.ok(e.getMessage()).status(500).build();
			}
		}
		return Response.ok("noFacade").status(200).build();

	}

	@GET
	@Path("details")
	public Response veiwCompDetails() {
		getUpdatedFacade();
		if (facade != null) {
			Company coreResult;
			try {
				coreResult = facade.veiwCompDetails();
				CompanyWeb result = new CompanyWeb(coreResult);
				return Response.ok(result).status(200).build();
			} catch (CouponSystemException e) {
				e.printStackTrace();
				return Response.ok(e.getMessage()).status(500).build();
			}
		}
		return Response.ok("noFacade").status(200).build();

	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("coupon")
	public Response createCoupon(CouponWeb couponWeb) {

		getUpdatedFacade();
		if (facade != null) {

			Coupon coupon = couponWeb.convertToCoupon();
			try {
				facade.createCoupon(coupon);
				CouponWeb result = new CouponWeb(coupon);
				return Response.ok(result).status(200).build();
			} catch (CouponSystemException e) {

				e.printStackTrace();
				return Response.ok(e.getMessage()).status(500).build();
			}
		}
		return Response.ok("noFacade").status(200).build();
	}

	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("coupon")
	public Response updateCoupon(CouponWeb couponWeb) {
		getUpdatedFacade();
		if (facade != null) {
			Coupon coupon = couponWeb.convertToCoupon();
			try {
				facade.updateCoupon(coupon);
				return Response.ok(new CouponWeb(facade.getCoupon(couponWeb.getId()))).status(200).build();
			} catch (CouponSystemException e) {
				e.printStackTrace();
				return Response.ok(e.getMessage()).status(500).build();
			}
		}
		return Response.ok("noFacade").status(200).build();
	}

	@DELETE
	@Path("coupon/{id}")
	public Response deleteCoupon(@PathParam("id") long coupId) {
		getUpdatedFacade();
		if (facade != null) {
			Coupon coupon;
			try {
				coupon = facade.getCoupon(coupId);
				facade.deleteCoupon(coupon);
				return Response.ok(new CouponWeb(coupon)).status(200).build();
			} catch (CouponSystemException e) {
				e.printStackTrace();
				return Response.ok(e.getMessage()).status(500).build();
			}
		}
		return Response.ok("noFacade").status(200).build();

	}
	
	
	
	
	
//	@GET
//	@Path("getSessionCoupToCreate")
//	public Response getCouponWebFromSession() {
//		CouponWeb coupon = (CouponWeb) request.getSession().getAttribute("couponWeb");
//		if (coupon instanceof CouponWeb) {
//			return Response.ok(coupon).status(200).build();
//		} 
//		return Response.ok("there was no coupon in the session").status(500).build();
//	}
//	
//	@POST
//	@Consumes(MediaType.APPLICATION_JSON)
//	@Path("directToImage")
//	public Response directToImage(CouponWeb couponWeb) {
//
//		request.getSession().setAttribute("couponToCreate", couponWeb);
//		
//		
//		return Response.ok("compPage3.html#/image").status(200).build();
//	}
//	@POST
//	@Path("backToCreate/{image}")
//	public Response backToCreateCoup(@PathParam("image") String image) {
//		CouponWeb coupon = (CouponWeb) request.getSession().getAttribute("couponWeb");
//		if (coupon instanceof CouponWeb) {
//			coupon.setImage(image);
//			request.getSession().setAttribute("couponToCreate", coupon);
//		} 
//		
//		
//		return Response.ok("compPage3.html#/create").status(200).build();
//	}

}
