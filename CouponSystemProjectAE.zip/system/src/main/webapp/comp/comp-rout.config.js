(function () {
  
       var module = angular.module("compApp");
   
          
           module.config(['$locationProvider', function ($locationProvider) {
                   $locationProvider.hashPrefix('');
               }])
              
           // router config
           module.config(function ($stateProvider, $urlRouterProvider) {

           
               $stateProvider
               .state("details", {
                   url: "/details",
                   templateUrl: "compSubPages/viewCompDetails.html",
                   controller: "ViewDetailsCtrl as comp"
               })
               .state("getCoupons", {
                   url: "/getCoupons",
                   templateUrl: "compSubPages/getCoupons.html",
                   controller: "GetCouponsCtrl as comp"
               })
               .state("getCoupon", {
                url: "/getCoupon",
                templateUrl: "compSubPages/getCoupon.html",
                controller: "GetCouponCtrl as comp"
            })
               .state("getByType", {
                url: "/getByType",
                templateUrl: "compSubPages/getCoupByType.html",
                controller: "GetByTypeCtrl as comp"
               })
               .state("getByPrice", {
                url: "/getByPrice",
                templateUrl: "compSubPages/getCoupByLimit.html",
                controller: "GetByLimitCtrl as comp"
               })
               .state("getUntilDate", {
                url: "/getUntilDate",
                templateUrl: "compSubPages/getCoupUntilEndDate.html",
                controller: "GetUntilDateCtrl as comp"
               })
               .state("create", {
                url: "/create",
                templateUrl: "compSubPages/createCoupon.html",
                controller: "CreateCoupCtrl as comp"
               })
               .state("update", {
                url: "/update",
                templateUrl: "compSubPages/updateCoupon.html",
                controller: "UpdateCoupCtrl as comp"
               })
               .state("delete", {
                url: "/delete",
                templateUrl: "compSubPages/deleteCoupon.html",
                controller: "DeleteCoupCtrl as comp"
          
               });
              
         
       });
    
   })();

 
