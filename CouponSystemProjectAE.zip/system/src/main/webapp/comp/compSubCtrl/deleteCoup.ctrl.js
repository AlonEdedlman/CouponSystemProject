var module = angular.module("compApp")
module.controller("DeleteCoupCtrl", DeleteCoupCtrlCtor)



function DeleteCoupCtrlCtor(compServiceHTTP, ErrorHandlerSrvc) {

    this.errDetails = {"error": false, "msg":""};
    this.showTable = false;
    this.coupDelete={};
    this.compCoupons = []
    this.success = false;
    this.failure = false;

    var self = this;
    
this.deleteCoupon = function(){
    if (this.coupDelete.id == undefined || this.coupDelete.id == null )
        {
            this.success = false;
            this.failure = true;
            return;
        }
        this.success = false;
        this.failure = false;
    var promise = compServiceHTTP.deleteCoupon(this.coupDelete.id)
    promise.then(function(resp){
    console.log(resp.data);
    debug = resp;
    self.errDetails = {"error": false, "msg":""};
    self.getCoupons();
    self.success = true;
    self.failure = false;

    ErrorHandlerSrvc.checkData(resp.data);

    },
    function(err)
    {
        console.log(err)
        debug = err;
        self.success = false;
        self.failure = true;
        self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
    }
    ) 
}
this.getCoupons = function(){
    var promise = compServiceHTTP.getCoupons()
     promise.then(

        function (resp) {
            console.log(resp.data);
            debug = resp;
            self.errDetails = {"error": false, "msg":""};
            self.compCoupons = resp.data;

            ErrorHandlerSrvc.checkData(resp.data);
        },
        function (err) {
        	
            console.log(err)
            debug = err;
            self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
        }
    )
}

this.getCouponBeforeDelete = function(){
    self.showTable=true;
    
    var promise = compServiceHTTP.getCoupon(this.coupDelete.id)
    promise.then(
        
        function (resp) {
            console.log(resp.data);
            debug = resp;
            self.errDetails = {"error": false, "msg":""};
            self.coup = resp.data;

            ErrorHandlerSrvc.checkData(resp.data);
            
           
        },
        function (err) {
            
            console.log(err)
            debug = err;
            self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
        }
)
}

this.getCoupons()
}