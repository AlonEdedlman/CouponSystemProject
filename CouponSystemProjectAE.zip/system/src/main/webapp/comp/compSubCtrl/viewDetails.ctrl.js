var module = angular.module("compApp")
module.controller("ViewDetailsCtrl", ViewDetailsCtrlCtor)


function ViewDetailsCtrlCtor(compServiceHTTP, ErrorHandlerSrvc) {
   
   
	this.errDetails = {"error": false, "msg":""};
    var self = this;


    this.veiwCompDetails = function(){
        var promise = compServiceHTTP.veiwCompDetails()
        promise.then(
    			  
    			function (resp) {
    				console.log(resp.data);
    				debug = resp;
					self.details = resp.data;

					ErrorHandlerSrvc.checkData(resp.data);
					self.errDetails = {"error": false, "msg":""};
    			},
    			function (err) {
    				
    				console.log(err)
					debug = err;
					self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
    			}
    	)
    }

    this.veiwCompDetails();

}