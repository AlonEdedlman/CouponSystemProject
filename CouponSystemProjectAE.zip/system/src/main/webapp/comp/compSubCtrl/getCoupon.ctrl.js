var module = angular.module("compApp")
module.controller("GetCouponCtrl", GetCouponCtrlCtor)



function GetCouponCtrlCtor(compServiceHTTP, ErrorHandlerSrvc) {
   
    this.errDetails = {"error": false, "msg":""};
    this.showTable = false;
    this.compCoupons = [];
    var self = this;


   
    this.getCoupon = function(){
        var promise = compServiceHTTP.getCoupon(this.coupId)
        promise.then(
    		
    		function (resp) {
    			console.log(resp.data);
                debug = resp;
                self.errDetails = {"error": false, "msg":""};
                self.compCoupById = resp.data;
                self.showTable=true;

                ErrorHandlerSrvc.checkData(resp.data);
    		},
    		function (err) {
    			
    			console.log(err)
                debug = err;
                self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
    		}
    )
    }

   this.getCoupons = function(){
    var promise = compServiceHTTP.getCoupons()
     promise.then(

        function (resp) {
            console.log(resp.data);
            debug = resp;
            self.errDetails = {"error": false, "msg":""};
            self.compCoupons = resp.data;

            ErrorHandlerSrvc.checkData(resp.data);
        },
        function (err) {
        	
            console.log(err)
            debug = err;
            self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
        }
    )
}

this.getCoupons()
this.coupon

}