var module = angular.module("compApp")
module.controller("UpdateCoupCtrl", UpdateCoupCtrlCtor)



function UpdateCoupCtrlCtor(compServiceHTTP, ErrorHandlerSrvc) {
    
    this.errDetails = {"error": false, "msg":""};
    this.compCoupons = [];
    this.coupUpdate = {};
    this.success = false;
    this.failure = false;
    this.showTable = false;

    var self = this;
    

    this.endDateToLongU = function(){
        
        var date = new Date(self.endDateU).getTime();
        self.coupUpdate.endDate = date;
        
    }
     this.updateCoupon = function(){
        self.endDateToLongU()
        
        var promise = compServiceHTTP.updateCoupon(this.coupUpdate)
        promise.then(function(resp){
          console.log(resp.data);
       debug = resp;
       self.errDetails = {"error": false, "msg":""};
       self.getCoupons();

       ErrorHandlerSrvc.checkData(resp.data);

        },
        function(err)
        {
            
         console.log(err)
         debug = err;
         self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
        }
        ) 
     }


this.getCoupons = function(){
    var promise = compServiceHTTP.getCoupons()

     promise.then(

        function (resp) {
            console.log(resp.data);
            debug = resp;
            self.compCoupons = resp.data;
            self.errDetails = {"error": false, "msg":""};
            
            ErrorHandlerSrvc.checkData(resp.data);

        },
        function (err) {
        	
            console.log(err)
            debug = err;
            self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
        }
    )
}
this.getCouponBeforeUpdate = function(){
    self.showTable=true;
    
    var promise = compServiceHTTP.getCoupon(this.coupId)
    promise.then(
        
        function (resp) {
            console.log(resp.data);
            debug = resp;
            self.errDetails = {"error": false, "msg":""};
            self.coupUpdate = resp.data;
            self.endDateU = new Date(self.coupUpdate.endDate);

            ErrorHandlerSrvc.checkData(resp.data);

        },
        function (err) {
            
            console.log(err)
            debug = err;
            self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
        }
)
}

this.getCoupons();
}