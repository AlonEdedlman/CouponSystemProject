var module = angular.module("compApp")
module.controller("CreateCoupCtrl", CreateCoupCtrlCtor)



function CreateCoupCtrlCtor(compServiceHTTP, ErrorHandlerSrvc) {

    this.coup = {"id":"","name":"","type":"","price":"","amount":"","startDate":"","endDate":"","image":"","type":"","message":""};
    this.errDetails = {"error": false, "msg":""};
    this.success = false;
    this.failure = false;
    this.minDate = new Date(new Date().setHours(0,0,0)-(1000*60*60));
    
    var self = this;


this.createCoupon = function(){
    
    if (this.coup.id == undefined || this.coup.title == undefined || this.startDate == undefined || this.endDate == undefined
        || this.coup.amount == undefined || this.coup.type == undefined || this.coup.message == undefined || this.coup.id == undefined 
        || this.coup.price == undefined || this.coup.image == undefined )
        {
            this.success = false;
            this.failure = true;
            self.errDetails = {"error": true, "msg":"please fill all the empty inputs"};
            return;
        }
        this.success = false;
        this.failure = false;
        
            this.startDateToLong();
            this.endDateToLong();
        		
        var promise = compServiceHTTP.createCoupon(this.coup)
        promise.then(

            function (resp) {
                console.log(resp.data);
                debug = resp;
                self.errDetails = {"error": false, "msg":""};
                self.success = true;
                self.failure = false;

                ErrorHandlerSrvc.checkData(resp.data);
                
            },
            function (err) {
            	
                console.log(err)
                debug = err;
                self.success = false;
                self.failure = true;
                
                self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
                        
            }
        )
        
    }
   
   this.startDateToLong = function(){
        
        var date = new Date(self.startDate).getTime();
        self.coup.startDate = date;
        
    }
   this.endDateToLong = function(){
       
       var date = new Date(self.endDate).getTime();
       self.coup.endDate = date;
       
   }

  this.checkId = function(){
     if(ErrorHandlerSrvc.checkNumberInputs(this.coup.id)){
        this.coup.id = "";
      }
  }
  this.checkAmount = function(){
    if(ErrorHandlerSrvc.checkNumberInputs(this.coup.amount)){
        this.coup.amount = "";
    }
    
 }
 this.checkPrice = function(){
   if(ErrorHandlerSrvc.checkNumberInputs(this.coup.price)){
       this.coup.price = "";
   }
 }
 this.checkStartDate = function(){
      if(ErrorHandlerSrvc.checkDateInputs(this.startDate)){
        this.startDate = "";
     }
 }
 this.checkEndDate = function(){
   
    if(ErrorHandlerSrvc.checkDateInputs(this.endtDate)){
        this.endtDate = "";
     }
}

   /*
   this.directToCreateImg = function(){
    var promise = compServiceHTTP.directToSelectImage(this.coup)
    
    promise.then(
        
                    function (resp) {
                        console.log(resp.data);
                        debug = resp;
                        self.errDetails = {"error": false, "msg":""};
                        window.location.href = resp.data;
                        
                    },
                    function (err) {
                        
                        console.log(err)
                        debug = err;
                        self.errDetails = {"error": true, "msg":"direct to choose image faild!"};
                        self.coup = {};
                        
                    }
                )
    
}
this.getCouponWebFromSession = function(){
    var promise = compServiceHTTP.getCouponWebFromSession()
    promise.then(
        
                    function (resp) {
                        console.log(resp.data);
                        debug = resp;
        
                        self.coup = resp.data;
                        
                        
                    },
                    function (err) {
                        
                        console.log(err)
                        debug = err;
                        
                        self.coup = {};
                        
                    }
                )
}
   this.getCouponWebFromSession();*/
}