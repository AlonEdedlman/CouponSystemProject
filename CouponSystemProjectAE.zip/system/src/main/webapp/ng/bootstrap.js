//angular.module("myApp", [])
angular.module("compApp", ["ui.router"])
//angular.module("custApp", [])
//angular.module("adminApp", [])