(function()
{

    var module = angular.module("adminApp");

    module.service("ErrorHandlerSrvc", ErrorHandlerSrvcCtor);

    

        function ErrorHandlerSrvcCtor()
            {

              this.result = {"error": false, "data":""};
              var self = this;
              this.emptyChek = function(value){

                if(value==""){
                   return false;
                }
                return true;
              }

              this.nullCheck = function(value){
                  if(value == null || value == undefined){
                      return false;
                  }
                  return true;
              } 

             

                  this.checkData = function(data){
                    if(data == "noFacade"){
                        window.location.href = "../login/login.html";
                    }
                  }

                

                  this.getErrDetails = function(err){
                    var result = {"error": false, "msg":""};
                    if(err.status==500){
                        result.error = true;
                        result.msg = err.data;
                    }
                    if(err.status==404){
                        result.error = true;
                        result.msg = "there was an error!";
                    }
                    return result;
                  }
              }
    })();
