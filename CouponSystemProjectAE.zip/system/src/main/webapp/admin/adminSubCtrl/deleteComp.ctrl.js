var module = angular.module("adminApp")
module.controller("DeleteCompCtrl", DeleteCompCtrlCtor)

function DeleteCompCtrlCtor(adminServiceHTTP, ErrorHandlerSrvc) {

    this.errDetails = {"error": false, "msg":""};
    this.compDelete={};
    this.companies = [];
    this.success = false;
    this.failure = false;

    var self = this;
    


this.deleteCompany = function(){

    if (this.compDelete.id == undefined || this.compDelete.id == null )
    {
        this.success = false;
        this.failure = true;
        return;
    }
    this.success = false;
    this.failure = false;

    var promise = adminServiceHTTP.deleteCompany(self.compDelete.id)
    promise.then(function(resp){
    console.log(resp.data);
    debug = resp;
    ErrorHandlerSrvc.checkData(resp.data);
    self.errDetails = {"error": false, "msg":""};
     self.success = true;
    self.failure = false;
    },
    function(err)
    {
        console.log(err)
        debug = err;
        self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
        self.getAllCompanies();
        self.success = false;
        self.failure = true;
    }
    ) 
}
this.getAllCompanies = function(){
    
                 var promise = adminServiceHTTP.getAllCompanies()
                 promise.then(
                    
                    function (resp) {
                        console.log(resp.data);
                        debug = resp;
                        ErrorHandlerSrvc.checkData(resp.data);
                        self.errDetails = {"error": false, "msg":""};
                        self.companies = resp.data;
                    },
                    function (err) {
                        
                        console.log(err)
                        debug = err;
                        self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
                    }
                )
            }

this.getAllCompanies();
}