var module = angular.module("adminApp")
module.controller("GetCompCtrl", GetCompCtrlCtor)

function GetCompCtrlCtor(adminServiceHTTP, ErrorHandlerSrvc) {

    this.errDetails = {"error": false, "msg":""};
    this.showTable = false;
    this.companies = [];
    var self = this;


    this.getCompany = function(){
        var promise = adminServiceHTTP.getCompany(self.compId)
        promise.then(
            
            function (resp) {
                console.log(resp.data);
                debug = resp;
                ErrorHandlerSrvc.checkData(resp.data);
                self.errDetails = {"error": false, "msg":""};
                self.compById = resp.data;
                self.showTable=true;
            },
            function (err) {
                
                console.log(err)
                debug = err;
                self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
            }
        )
    }
   
    
    this.getAllCompanies = function(){
        
                     var promise = adminServiceHTTP.getAllCompanies()
                     promise.then(
                        
                        function (resp) {
                            console.log(resp.data);
                            debug = resp;
                            ErrorHandlerSrvc.checkData(resp.data);
                            self.errDetails = {"error": false, "msg":""};
                            self.companies = resp.data;
                        },
                        function (err) {
                            
                            console.log(err)
                            debug = err;
                            self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
                        }
                    )
                }
   

this.getAllCompanies();
}

