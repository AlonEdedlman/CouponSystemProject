var module = angular.module("adminApp")
module.controller("CretaeCompCtrl", CretaeCompCtrlCtor)

function CretaeCompCtrlCtor(adminServiceHTTP, ErrorHandlerSrvc) {
    this.company = {};
    this.errDetails = {"error": false, "msg":""};
    this.errorMessage=false;
    this.success = false;
    this.failure = false;
    var self = this;
    
    this.createCompany = function(){

        if (this.company.id == undefined || this.company.compName == undefined || this.company.password == undefined || this.company.email == undefined )
            {
                this.success = false;
                this.failure = true;
                return;
            }
            this.success = false;
            this.failure = false;

        var promise = adminServiceHTTP.createCompany(self.company)
        promise.then(
            function (resp) {
                console.log(resp.data);
                debug = resp;
                ErrorHandlerSrvc.checkData(resp.data);
                self.errDetails = {"error": false, "msg":""};
                
                self.success = true;
                self.failure = false;
               },
               function (err) {
                   
                   console.log(err)
                   debug = err;
                   self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
                   self.success = false;
                   self.failure = true;
               }
        )
    }
    
}