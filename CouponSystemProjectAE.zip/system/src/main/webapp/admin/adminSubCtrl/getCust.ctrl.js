var module = angular.module("adminApp")
module.controller("GetCustCtrl", GetCustCtrlCtor)

function GetCustCtrlCtor(adminServiceHTTP, ErrorHandlerSrvc) {

    this.errDetails = {"error": false, "msg":""};
    this.showTable = false;
    this.customers = [];
    var self = this;


    this.getCustomer = function(){
        var promise = adminServiceHTTP.getCustomer(self.custId)
        promise.then(
            
            function (resp) {
                console.log(resp.data);
                debug = resp;
                ErrorHandlerSrvc.checkData(resp.data);
                self.errDetails = {"error": false, "msg":""};
                self.custById = resp.data;
                self.showTable=true;
            },
            function (err) {
                
                console.log(err)
                debug = err;
                self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
            }
        )
    }

   
    this.getAllCustomers = function(){
        
                var promise = adminServiceHTTP.getAllCustomers()
                promise.then(function (resp) {
                         console.log(resp.data);
                         debug = resp;
                         ErrorHandlerSrvc.checkData(resp.data);
                         self.errDetails = {"error": false, "msg":""};
                         self.customers = resp.data;
                        
                        },
                        function (err) {
                            
                            console.log(err)
                            debug = err;
                            self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
                        }
                    )
                    
                } 
    
    

 this.getAllCustomers();
}

