(function () {
    
         var module = angular.module("adminApp");
     
            
             module.config(['$locationProvider', function ($locationProvider) {
                     $locationProvider.hashPrefix('');
                 }])
            
             // router config
             module.config(function ($stateProvider, $urlRouterProvider) {
  //company
            
                 $stateProvider
                 .state("getAllCompanies", {
                     url: "/getAllCompanies",
                     templateUrl: "adminSubPages/getAllCompanies.html",
                     controller: "GetAllCompCtrl as admin"
                 })
                 $stateProvider
                 .state("getCompany", {
                     url: "/getCompany",
                     templateUrl: "adminSubPages/getCompany.html",
                     controller: "GetCompCtrl as admin"
                 })
                 $stateProvider
                 .state("createCompany", {
                     url: "/createCompany",
                     templateUrl: "adminSubPages/createCompany.html",
                     controller: "CretaeCompCtrl as admin"
                 })
                 $stateProvider
                 .state("updateCompany", {
                     url: "/updateCompany",
                     templateUrl: "adminSubPages/updateCompany.html",
                     controller: "UpdateCompCtrl as admin"
                 })
                 $stateProvider
                 .state("deleteCompany", {
                     url: "/deleteCompany",
                     templateUrl: "adminSubPages/deleteCompany.html",
                     controller: "DeleteCompCtrl as admin"
                 })
            
//customer

                 $stateProvider
                 .state("getAllCustomers", {
                     url: "/getAllCustomers",
                     templateUrl: "adminSubPages/getAllCustomers.html",
                     controller: "GetAllCustCtrl as admin"
                 })
                 $stateProvider
                 .state("getCustomer", {
                     url: "/getCustomer",
                     templateUrl: "adminSubPages/getCustomer.html",
                     controller: "GetCustCtrl as admin"
                 })
                 $stateProvider
                 .state("createCustomer", {
                     url: "/createCustomer",
                     templateUrl: "adminSubPages/createCustomer.html",
                     controller: "CretaeCustCtrl as admin"
                 })
                 $stateProvider
                 .state("updateCustomer", {
                     url: "/updateCustomer",
                     templateUrl: "adminSubPages/updateCustomer.html",
                     controller: "UpdateCustCtrl as admin"
                 })
                 $stateProvider
                 .state("deleteCustomer", {
                     url: "/deleteCustomer",
                     templateUrl: "adminSubPages/deleteCustomer.html",
                     controller: "DeleteCustCtrl as admin"
                 })
         });
      
     })();