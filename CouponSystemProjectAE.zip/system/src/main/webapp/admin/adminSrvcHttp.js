(function()
{

    var module = angular.module("adminApp");

    module.service("adminServiceHTTP", adminServiceHTTPCtor);


        function adminServiceHTTPCtor( $http )
            {

                   
            this.getAllCompanies = function(){

                var promise = $http.get('http://localhost:8080/system/webapi/admin/company')
                return promise
          }
           this.getCompany = function(compId){
            var promise = $http.get('http://localhost:8080/system/webapi/admin/company/'+ compId)
            return promise
          }
           this.createCompany = function(company){
            var promise = $http.post('http://localhost:8080/system/webapi/admin/company',company)
            return promise   
         }
         this.updateCompany = function(compUpdate){
           
            var promise = $http.put('http://localhost:8080/system/webapi/admin/company', compUpdate)
            return promise
         }
         this.deleteCompany = function(id){
            var promise = $http.delete('http://localhost:8080/system/webapi/admin/company/' + id)
            return promise
         }
        this.getAllCustomers = function(){

            var promise = $http.get('http://localhost:8080/system/webapi/admin/customer')
            return promise
          } 
          this.getCustomer = function(custId){
            var promise = $http.get('http://localhost:8080/system/webapi/admin/customer/'+custId)
            return promise
          }
          this.createCustomer = function(customer){
            var promise = $http.post('http://localhost:8080/system/webapi/admin/customer',customer)
            return promise
         }

         this.updateCustomer = function(custUpdate){
            var promise = $http.put('http://localhost:8080/system/webapi/admin/customer', custUpdate)
            return promise
         }
         this.deleteCustomer = function(id){
            var promise = $http.delete('http://localhost:8080/system/webapi/admin/customer/' + id)
            return promise
         }
                
            }


    })();
