var module = angular.module("custApp")
module.controller("GetPCouponsCtrl", GetPCouponsCtrlCtor)



function GetPCouponsCtrlCtor(custServiceHTTP, ErrorHandlerSrvc) {

   this.errDetails = {"error": false, "msg":""};
    this.custCoupons = []
    
     var self = this;
 
     this.orderB = "";
     this.goUp = false;
     
     this.setOrder = function (field) {
         this.goUp = (this.orderB != field) ? false : !this.goUp;
         this.orderB = field;
         console.log(this.orderB)
         this.getAllPurchasedCoupons();
 
     }
     
      this.getAllPurchasedCoupons = function(){
         var promise = custServiceHTTP.getAllPurchasedCoupons()
         promise.then(
 
         function (resp) {
             console.log(resp.data);
             debug = resp;
             self.errDetails = {"error": false, "msg":""};
             ErrorHandlerSrvc.checkData(resp.data);
             self.custCoupons = resp.data;
         },
         function (err) {
 
             console.log(err)
             debug = err;
             self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
         }
     )
      }


      this.getAllPurchasedCoupons();
   
}