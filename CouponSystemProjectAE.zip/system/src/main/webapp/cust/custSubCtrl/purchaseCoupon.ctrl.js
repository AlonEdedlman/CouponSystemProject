var module = angular.module("custApp")
module.controller("PurchaseCouponCtrl", PurchaseCouponCtrlCtor)



function PurchaseCouponCtrlCtor(custServiceHTTP, ErrorHandlerSrvc) {

    this.errDetails = {"error": false, "msg":""};
    this.coupons = []
    
    this.success = false;
    this.failure = false;

     var self = this;
 
     this.orderB = "";
     this.goUp = false;
     
     this.setOrder = function (field) {
         this.goUp = (this.orderB != field) ? false : !this.goUp;
         this.orderB = field;
         console.log(this.orderB)
         this.getAllCouponsToPurchase();
 
     }
     

      this.purchaseCoupon = function(coupon){
        var promise = custServiceHTTP.purchaseCoupon(coupon)
        promise.then(

                    function (resp) {
                        console.log(resp.data);
                        debug = resp;
                        self.errDetails = {"error": false, "msg":""};
                        ErrorHandlerSrvc.checkData(resp.data);
                        self.getAllCouponsToPurchase();
                        self.success = true;
                        self.failure = false;
                    },
                    function (err) {
            
                        console.log(err)
                        debug = err;
                        self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
                        self.success = false;
                        self.failure = true;
                    }
                )
                 }

     this.getAllCouponsToPurchase = function(){
        
        var promise = custServiceHTTP.getAllCouponsToPurchase()
        promise.then(

                    function (resp) {
                        console.log(resp.data);
                        debug = resp;
                        self.errDetails = {"error": false, "msg":""};
                        ErrorHandlerSrvc.checkData(resp.data);
                        self.coupons = resp.data;

                        
                    },
                    function (err) {
            
                        console.log(err)
                        debug = err;
                        self.errDetails = ErrorHandlerSrvc.getErrDetails(err);
                    }
                )
                 }
     
   this.getAllCouponsToPurchase();
}