(function()
{

    var module = angular.module("custApp");

    module.service("custServiceHTTP", custServiceHTTPCtor);


        function custServiceHTTPCtor( $http )
            {

      
                    
     this.getAllPurchasedCoupons = function(){
        var promise = $http.get('http://localhost:8080/system/webapi/customer/coupon')
        return promise
    }

    this.getAllCouponsToPurchase =  function(){
        var promise = $http.get('http://localhost:8080/system/webapi/customer/purchase')
        return promise
    }

    this.getAllPurchasedCouponsByType = function(coupType){
        var promise = $http.get('http://localhost:8080/system/webapi/customer/getByType/'+ coupType)
        return promise
                }
    this.getAllPurchasedCouponByLimit = function(coupLimit){
      
        var promise = $http.get('http://localhost:8080/system/webapi/customer/getByLimit/'+ coupLimit)
        return promise
                }
    this.purchaseCoupon = function(couponToPurchse){
        var promise = $http.post('http://localhost:8080/system/webapi/customer/coupon', couponToPurchse)
        return promise
                }
              
                
            }


    })();
