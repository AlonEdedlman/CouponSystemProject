(function () {
    
         var module = angular.module("custApp");
    
             
             module.config(['$locationProvider', function ($locationProvider) {
                     $locationProvider.hashPrefix('');
                 }])
               
        
             module.config(function ($stateProvider, $urlRouterProvider) {
  
            
                 $stateProvider
                 .state("getCoupons", {
                     url: "/getCoupons",
                     templateUrl: "custSubPages/getPCoupons.html",
                     controller: "GetPCouponsCtrl as cust"
                 })
                 .state("getByType", {
                     url: "/getByType",
                     templateUrl: "custSubPages/getPCoupByType.html",
                     controller: "GetPCoupByTypeCtrl as cust"
                 })
                 .state("getByPrice", {
                  url: "/getByPrice",
                  templateUrl: "custSubPages/getPCoupByLimit.html",
                  controller: "GetPCoupByLimitCtrl as cust"
                 })
                 .state("purchaseCoupon", {
                    url: "/purchaseCoupon",
                    templateUrl: "custSubPages/purchaseCoupon.html",
                    controller: "PurchaseCouponCtrl as cust"
                   })
                
              
         });
      
     })();